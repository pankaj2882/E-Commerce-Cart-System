import React, { useState } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import "./checkout.css";
import "./OrderConfirmation.css";

export const Checkout = () => {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({ name: "", email: "", address: "" });

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    navigate("/order-confirmation", { state: { ...formData } });
  };

  return (
    <div className="checkout-container">
      <h2>Checkout</h2>
      <form onSubmit={handleSubmit} className="checkout-form">
        <div className="form-group">
          <label>Name:</label>
          <input type="text" name="name" value={formData.name} onChange={handleChange} required />
        </div>
        <div className="form-group">
          <label>Email:</label>
          <input type="email" name="email" value={formData.email} onChange={handleChange} required />
        </div>
        <div className="form-group">
          <label>Address:</label>
          <input type="text" name="address" value={formData.address} onChange={handleChange} required />
        </div>
        <button type="submit" className="submit-button">Place Order</button>
      </form>
    </div>
  );
};

export const OrderConfirmation = () => {
  const location = useLocation();
  console.log("OrderConfirmation Mounted:", location);

  const state = location.state || { name: "Guest", email: "Not provided", address: "Not provided" };

  return (
    <div className="confirmation-container">
      <h2>Order Confirmation</h2>
      <p>Thank you for your order, {state.name}!</p>
      <p>Email: {state.email}</p>
      <p>Address: {state.address}</p>
    </div>
  );
};

