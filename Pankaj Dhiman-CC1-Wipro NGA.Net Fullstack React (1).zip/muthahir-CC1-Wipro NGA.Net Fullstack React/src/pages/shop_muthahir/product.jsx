import React, { useContext } from "react";
import { ShopContext } from "../../context/shop-context";
import "./product.css";

export const Product = (props) => {
  const { id, productName, price, productImage } = props.data;
  const { addToCart, cartItems } = useContext(ShopContext);

  const cartItemCount = cartItems[id] || 0;

  return (
    <div className="product-card">
      <img src={productImage} alt={productName} className="product-image" />
      <div className="product-description">
        <p className="product-name">{productName}</p>
        <p className="product-price">${price}</p>
      </div>
      <button className="add-to-cart-button" onClick={() => addToCart(id)}>
        Add To Cart {cartItemCount > 0 && <span>({cartItemCount})</span>}
      </button>
    </div>
  );
};
